Free Icons by Axialis Software
http://www.axialis.com

Here is a library of icons that you can freely use in your projects. All
the icons are licensed under the Creative Commons Attribution License
(http://creativecommons.org/licenses/by/2.5/). It means that you can use
them in any project or website, commercially or not.

The icons have been created by Axialis IconWorkshop, the professional
icon authoring tool for Windows. For more info visit this page:
http://www.axialis.com/iconworkshop

TERMS OF USE
The only restrictions are: (a) you must keep the credits of the authors:
"Axialis Team", even if you modify them; (b) link to us if you use them
on your website (see below).

LINK TO US
If you use the icons in your website, you must add the following link on
EACH PAGE containing the icons (at the bottom of the page for example).
The HTML code for this link is:

  <a href="http://www.axialis.com/free/icons">Icons</a> by <a href="http://www.axialis.com">Axialis Team</a>





